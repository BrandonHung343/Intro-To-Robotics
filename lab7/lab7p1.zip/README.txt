If you have the following libraries installed:
	- matplotlib
	- numpy

then run part1.py as a python3 script (should auto run with py3, has shebang at top) and will produce a graph.

If not, please look at attached image.